function test_suite = testCreateScaling(varargin)
#TESTCREATESCALING  One-line description here, please.
#   output = testCreateScaling(input)
#
#   Example
#   testCreateScaling
#
#   See also
#
#
# ------
# Author: David Legland
# e-mail: david.legland@grignon.inra.fr
# Created: 2009-04-22,    using Matlab 7.7.0.471 (R2008b)
# Copyright 2009 INRA - Cepia Software Platform.
# Licensed under the terms of the LGPL, see the file "license.txt"

initTestSuite;

function testCentered

